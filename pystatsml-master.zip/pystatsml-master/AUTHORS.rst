Authors
========

Editors
--------

- Edouard Duchesnay (edouard.duchesnay@gmail.com)

Chapter authors 
----------------

Listed by alphabetical order.

- Younes Feki (younesfkih@gmail.com)

- Tommy Löfstedt (lofstedt.tommy@gmail.com)


