Labs
====

- Supervized classification: face recognition



