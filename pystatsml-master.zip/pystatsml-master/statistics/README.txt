Univariate statistics
=====================

- Estimators of the main statistical measuresx
- Main distributions
- Hypothesis Testing
- Testing pairwise associations
- Non-parametric test of pairwise associations
- Linear model
- Linear model with statsmodels
- Multiple comparisons
- Labs


