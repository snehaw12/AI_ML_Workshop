Miscellaneous python scripts used in the document.
Files prefixed by `plot_`  are actually used to generate some figures.
