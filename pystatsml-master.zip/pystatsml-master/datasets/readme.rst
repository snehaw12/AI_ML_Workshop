default of credit card clients Data Set 
=======================================

http://archive.ics.uci.edu/ml/datasets/default+of+credit+card+clients
